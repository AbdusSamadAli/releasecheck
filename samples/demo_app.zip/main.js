const { app, BrowserWindow } = require('electron')
const config = require('./config.js')

function createWindow() {
  const win = new BrowserWindow({ width: 1000, height: 700 })
  win.loadFile('index.html')
  win.webContents.openDevTools()
}

app.whenReady().then(createWindow)
