module.exports = {
  apiBase: 'http://localhost:3000/api',
  apiKey: 'sk_test_FAKE1234567890abcdef',
  debug: true,
  payments: { mode: 'fake', chargeCards: false }
}
