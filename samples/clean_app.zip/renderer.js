async function loadNotes() {
  const res = await fetch('https://notes-api.example.com/v1/notes')
  return res.json()
}
