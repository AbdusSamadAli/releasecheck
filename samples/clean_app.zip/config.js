module.exports = {
  apiBase: 'https://notes-api.example.com/v1',
  debug: false
}
